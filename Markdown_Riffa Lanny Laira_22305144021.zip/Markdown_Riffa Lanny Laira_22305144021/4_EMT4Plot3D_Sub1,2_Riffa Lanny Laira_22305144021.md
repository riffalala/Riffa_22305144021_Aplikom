﻿# 4_EMT4Plot3D_Sub1,2_Riffa Lanny Laira_22305144021
# Presentasi Menggambar Plot 3D dengan EMT

RIFFA LANNY LAIRA


22305144021


MATEMATIKA E 2022


# 1. Menggambar Grafik Fungsi Dua Variabel

* dalam Bentuk Ekspresi Langsung 


Fungsi Dua Variabel didefinisikan sebagai sebuah fungsi bernilai real
dari dua variabel real, yakni fungsi f yang memadankan setiap pasangan


terurut (x,y) pada suatu himpunan D dari bidang dengan bilangan real


tunggal f (x,y).


Di dalam program numerik EMT, ekspresi adalah string. Jika ditandai
sebagai simbolis, mereka akan mencetak melalui Maxima, jika tidak
melalui EMT. Ekspresi dalam string digunakan untuk membuat plot dan
banyak fungsi numerik. Untuk ini, variabel dalam ekspresi harus "x"
dan "y".


Untuk grafik suatu fungsi, gunakan


* 
ekspresi sederhana dalam x dan y,

* 
nama fungsi dari dua variabel

* 
atau matriks data.


## Grafik Fungsi Linear



Fungsi linear dua variabel biasanya dinyatakan dalam bentuk


$$f(x,y)=ax+by+c$$\>plot3d("x^2+y^2"):


![images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-002.png](images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-002.png)

\>plot3d("x^2+5\*y^2"):


![images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-003.png](images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-003.png)

## Grafik Fungsi Kuadrat



Fungsi kuadrat dua variabel biasanya dinyatakan dalam bentuk


$$f(x,y)=ax^2+by^2+cxy+dx+ey+f$$\>plot3d("x^2\*y+3\*y^2"):


![images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-005.png](images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-005.png)

\>plot3d("x^2+y^2+-x+y-4"):


![images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-006.png](images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-006.png)

## Grafik Fungsi Akar Kuadrat

\>plot3d("sqrt(x^2+y^2)"):


![images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-007.png](images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-007.png)

\>plot3d("sqrt(x^2+5\*y^2)"):


![images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-008.png](images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-008.png)

## Grafik Fungsi Trigonometri

\>plot3d("sin(x)\*cos(y)"):


![images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-009.png](images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-009.png)

\>aspect(1.5); plot3d("x^2+sin(y)",-5,5,0,6\*pi):


![images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-010.png](images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-010.png)

1. aspect(1.5) mengatur aspek rasio pada grafik 3D.


2. plot3d("x^2+sin(y)",-5,5,0,6*pi) adalah fungsi matematika yang
digunakan untuk membuat grafik 3D.


3. -5,5 mengatur rentang sumbu x yang akan ditampilkan pada grafik.


4. 0,6*pi mengatur rentang sumbu y yang akan ditampilkan pada grafik.


## Grafik Fungsi Eksponensial



Fungsi eksponensial dua variabel bisa dinyatakan


$$f(x,y)=a.b^{xy}$$\>plot3d("4\*5^(x\*y)"):


![images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-012.png](images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-012.png)

\>plot3d("-7^(x\*y)"):


![images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-013.png](images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-013.png)

## Grafik Fungsi Logaritma



Fungsi logaritma dua variabel bisa dinyatakan sebagai


$$f(x,y)=log_b(xy)$$\>plot3d("log(x\*y)"):


![images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-015.png](images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-015.png)

\>plot3d("log(4x\*y)"):


![images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-016.png](images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-016.png)

\> 


# 2. Menggambar Grafik Fungsi Dua Variabel yang

* Rumusnya Disimpan dalam Variabel Ekspresi
Fungsi ini dapat memplot plot 3D dengan grafik fungsi dua


variabel, permukaan berparameter, kurva ruang, awan titik,


penyelesaian persamaan tiga variabel. Semua plot 3D bisa


ditampilkan sebagai anaglyph.


fungsi plot3d (x, y, z, xmin, xmax, ymin, ymax, n, a


Parameter


x : ekspresi dalam x dan y


x,y,z : matriks koordinat suatu permukaan


x,y,z : ekspresi dalam x dan y untuk permukaan parametrik


x,y,z : ekspresi dalam x untuk memplot kurva ruang


xmin,xmax,ymin,ymax :


  x,y batas ekspresi


contoh:


ekspresi dalam string


\>expr := "x^2+sin(y)"


    x^2+sin(y)

plot ekspresi


\>plot3d(expr,-5,5,0,6\*pi):


![images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-017.png](images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-017.png)

1. x^2+sin(y) adalah fungsi matematika yang digunakan untuk membuat
grafik 3D.


2. -5,5 mengatur rentang sumbu x yang akan ditampilkan pada grafik.


3. 0,6*pi mengatur rentang sumbu y yang akan ditampilkan pada grafik.


\>expr := "4\*x^3\*y" 


    4*x^3*y

\>aspect(1.5); plot3d(expr): 


![images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-018.png](images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-018.png)

1. aspect(2) mengatur aspek rasio pada grafik 3D.


2. plot3d(expr) adalah fungsi matematika yang digunakan untuk membuat
grafik 3D.


\>expr := "cos(x)\*sin(y)"


    cos(x)*sin(y)

\>plot3d(expr): 


![images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-019.png](images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-019.png)

\>expr := "y^2-x^2"


    y^2-x^2

\>aspect(1.5); plot3d(expr,-5,5,-5,5):


![images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-020.png](images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-020.png)

1. aspect(1.5) mengatur aspek rasio pada grafik 3D.


2. plot3d(expr,-5,5,-5,5) adalah fungsi matematika yang digunakan
untuk membuat grafik 3D.


3. -5,5 mengatur rentang sumbu x yang akan ditampilkan pada grafik.


4. -5,5 mengatur rentang sumbu y yang akan ditampilkan pada grafik.


## Fungsi umum untuk plot 3D.

Fungsi plot3d (x, y, z, xmin, xmax, ymin, ymax, n, a,  ..,


c, d, r, scale, fscale, frame, angle, height, zoom, distance, ..)


Rentang plot untuk fungsi dapat ditentukan dengan


- a,b: rentang x


- c,d: rentang y


- r : persegi simetris di sekitar (0,0).


- n : jumlah subinterval untuk plot.


Ada beberapa parameter untuk menskalakan fungsi atau mengubah tampilan
grafik.


- fscale: menskalakan ke nilai fungsi (defaultnya adalah &lt;fscale).


- scale: angka atau vektor 1x2 untuk menskalakan ke arah x dan y.


- frame: jenis bingkai (default 1).


Tampilan dapat diubah dengan berbagai cara.


- distance: jarak pandang ke plot.


- zoom: nilai zoom.


- angle: sudut terhadap sumbu y negatif dalam radian.


- height: ketinggian pandangan dalam radian.


Nilai default dapat diperiksa atau diubah dengan fungsi view(). Ini
mengembalikan parameter dalam urutan di atas.


\>view 


    [5,  2.6,  2,  0.4]

Jarak yang lebih dekat membutuhkan lebih sedikit zoom. Efeknya lebih
seperti lensa sudut lebar.


contoh soal:


\>plot3d("exp(-(x^2+y^2)/5)",r=10,n=80,fscale=4,scale=1.2,frame=3,\>user):


![images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-021.png](images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-021.png)

1. exp(-(x^2+y^2)/5) adalah fungsi matematika yang digunakan untuk
membuat grafik 3D.


2. r=10 mengatur jarak maksimum dari pusat grafik ke tepi grafik.


3. n=80 mengatur jumlah titik yang digunakan untuk membuat grafik.


4. fscale=4 mengatur faktor skala untuk warna.


5. scale=1.2 mengatur faktor skala untuk ukuran grafik.


6. frame=3 mengatur jenis bingkai yang digunakan untuk grafik.


Pada contoh berikut, sudut=0 dan tinggi=0 dilihat dari sumbu y
negatif. Label sumbu untuk y disembunyikan dalam kasus ini.


\>plot3d("x^2+y",distance=3,zoom=1,angle=pi/2,height=0):


![images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-022.png](images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-022.png)

1. x^2+y adalah fungsi matematika yang digunakan untuk membuat grafik
3D.


2. distance=3 mengatur jarak pandang dari grafik.


3. zoom=1 mengatur faktor perbesaran grafik.


4. angle=pi/2 mengatur sudut pandang grafik dalam radian.


5. height=0 mengatur ketinggian pandangan dari grafik.


Plot selalu terlihat berada di tengah kubus plot. Anda dapat
memindahkan bagian tengah dengan parameter tengah.


\>plot3d("x^4+y^2",a=0,b=1,c=-1,d=1,angle=-20°,height=20°, ...  
\>     center=[0.4,0,0],zoom=5):


![images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-023.png](images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-023.png)

1. x^4+y^2 adalah fungsi matematika yang digunakan untuk membuat
grafik 3D.


2. a=0,b=1,c=-1,d=1 mengatur rentang sumbu x dan y yang akan
ditampilkan pada grafik.


3. angle=-20° mengatur sudut pandang grafik dalam derajat.


4. height=20° mengatur ketinggian pandangan dari grafik dalam derajat.


5. center=[0.4,0,0] mengatur pusat pandangan dari grafik.


6. zoom=5 mengatur faktor perbesaran grafik.


Plotnya diskalakan agar sesuai dengan unit kubus untuk dilihat. Jadi
tidak perlu mengubah jarak atau zoom tergantung ukuran plot. Namun
labelnya mengacu pada ukuran sebenarnya.


Jika Anda mematikannya dengan scale=false, Anda harus berhati-hati
agar plot tetap masuk ke dalam jendela plotting, dengan mengubah jarak
pandang atau zoom, dan memindahkan bagian tengah.


\>plot3d("5\*exp(-x^2-y^2)",r=2,<fscale,<scale,distance=13,height=50°, ...  
\>     center=[0,0,-2],frame=3):


![images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-024.png](images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-024.png)

1. 5*exp(-x^2-y^2) adalah fungsi matematika yang digunakan untuk
membuat grafik 3D.


2. r=2 mengatur jarak maksimum dari pusat grafik ke tepi grafik.


3. &lt;fscale mengatur faktor skala untuk warna.


4. &lt;scale mengatur faktor skala untuk ukuran grafik.


5. distance=13 mengatur jarak pandang dari grafik.


6. height=50° mengatur ketinggian pandangan dari grafik dalam derajat.


7. center=[0,0,-2] mengatur pusat pandangan dari grafik.


8. frame=3 mengatur jenis bingkai yang digunakan untuk grafik.


Plot kutub juga tersedia. Parameter polar=true menggambar plot kutub.
Fungsi tersebut harus tetap merupakan fungsi dari x dan y. Parameter
"fscale" menskalakan fungsi dengan skalanya sendiri. Kalau tidak,
fungsinya akan diskalakan agar sesuai dengan kubus.


\>plot3d("1/(x^2+y^2+1)",r=5,\>polar, ...  
\>   fscale=2,\>hue,n=100,zoom=4,\>contour,color=blue):


![images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-025.png](images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-025.png)

1. 1/(x^2+y^2+1) adalah fungsi matematika yang digunakan untuk membuat
grafik 3D.


2. r=5 mengatur jarak maksimum dari pusat grafik ke tepi grafik.


3. polar mengatur tampilan grafik dalam koordinat polar.


4. fscale=2 mengatur faktor skala untuk warna.


5. hue mengatur skala warna yang digunakan pada grafik.


6. n=100 mengatur jumlah titik yang digunakan untuk membuat grafik.


7. zoom=4 mengatur faktor perbesaran grafik.


8. contour mengatur tampilan garis kontur pada grafik.


9. color=blue mengatur warna garis kontur pada grafik.


\>function f(r) := exp(-r/2)\*cos(r); ...  
\>   plot3d("f(x^2+y^2)",\>polar,scale=[1,1,0.4],r=pi,frame=3,zoom=4):


![images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-026.png](images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-026.png)

1. function f(r) := exp(-r/2)*cos(r) adalah fungsi matematika yang
didefinisikan sebagai f(r) = e^(-r/2) * cos(r).


2. plot3d("f(x^2+y^2)",polar,scale=[1,1,0.4],r=pi,frame=3,zoom=4)
adalah perintah untuk membuat grafik 3D dari fungsi f(x^2+y^2).


3. polar mengatur tampilan grafik dalam koordinat polar.


4. scale=[1,1,0.4] mengatur faktor skala untuk ukuran grafik.


5. r=pi mengatur jarak maksimum dari pusat grafik ke tepi grafik.


6. frame=3 mengatur jenis bingkai yang digunakan untuk grafik.


7. zoom=4 mengatur faktor perbesaran grafik.


Parameter memutar memutar fungsi di x di sekitar sumbu x.


* 
rotate=1: Menggunakan sumbu x

* 
rotate=2: Menggunakan sumbu z


\>plot3d("x^2+1",a=-1,b=1,rotate=true,grid=5):


![images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-027.png](images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-027.png)

1. x^2+1 adalah fungsi matematika yang digunakan untuk membuat grafik
3D.


2. a=-1,b=1 mengatur rentang sumbu x yang akan ditampilkan pada
grafik.


3. rotate=true mengatur grafik agar dapat diputar secara interaktif.


4. grid=5 mengatur jumlah garis koordinat yang ditampilkan pada
grafik.


\>plot3d("x^2+1",a=-1,b=1,rotate=2,grid=5):


![images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-028.png](images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-028.png)

1. x^2+1 adalah fungsi matematika yang digunakan untuk membuat grafik
3D.


2. a=-1,b=1 mengatur rentang sumbu x yang akan ditampilkan pada
grafik.


3. rotate=2 mengatur grafik agar dapat diputar secara interaktif
dengan menggunakan mouse.


4. grid=5 mengatur jumlah garis koordinat yang ditampilkan pada
grafik.


\>plot3d("sqrt(25-x^2)",a=0,b=5,rotate=1):


![images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-029.png](images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-029.png)

1. sqrt(25-x^2) adalah fungsi matematika yang digunakan untuk membuat
grafik 3D.


2. a=0,b=5 mengatur rentang sumbu x yang akan ditampilkan pada grafik.


3. rotate=1 mengatur grafik agar dapat diputar secara interaktif.


\>plot3d("x\*sin(x)",a=0,b=6pi,rotate=2):


![images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-030.png](images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-030.png)

1. x*sin(x) adalah fungsi matematika yang digunakan untuk membuat
grafik 3D.


2. a=0,b=6pi mengatur rentang sumbu x yang akan ditampilkan pada
grafik.


3. rotate=2 mengatur grafik agar dapat diputar secara interaktif.


Berikut adalah plot dengan tiga fungsi.


\>plot3d("x","x^2+y^2","y",r=2,zoom=3.5,frame=3):


![images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-031.png](images/4_EMT4Plot3D_Sub1,2_Riffa%20Lanny%20Laira_22305144021-031.png)

1. x adalah fungsi matematika yang digunakan untuk menentukan nilai
sumbu x pada grafik.


2. x^2+y^2 adalah fungsi matematika yang digunakan untuk menentukan
nilai sumbu z pada grafik.


3. y adalah fungsi matematika yang digunakan untuk menentukan nilai
sumbu y pada grafik.


4. r=2 mengatur jarak maksimum dari pusat grafik ke tepi grafik.


5. zoom=3.5 mengatur faktor perbesaran grafik.


6. frame=3 mengatur jenis bingkai yang digunakan untuk grafik.


